<?php
include("conn.php");

?>

<html>
<head>
    <link rel="icon" href="img/favicon.png" sizes="32x32">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>XYZ</title>
    <link rel="stylesheet" href="css/form_style.css">
</head>
<body>
    <header class="header">
        XYZ
    </header>
    <main class="main-container">
        <section class="form-container">
            <div class="alert-div"><strong>Note: </strong> Fields marked with <span style="color: red;">*</span> must be filled.</div>
            <form action="#" class="form">
                <div class="form__row">
                    <label for="name"><sup class="req">*</sup>Name : </label>
                    <input type="text" name="fname" id="name" class="form__input-text" placeholder="First Name" required />
                    <input type="text" name="lname" id="name" class="form__input-text" placeholder="Last Name" required/>
                </div><br>
                <div class="form__row">
                    <label for="address" style="align-self: flex-start;"><sup class="req">*</sup>Address : </label>
                    <textarea name="adr" id="address" cols="35" rows="5" class="form__textarea" placeholder="Enter your permanent address" required></textarea>
                </div><br>
                <div class="form__row">
                    <label for="gender">Gender: </label>
                    <div>
                    <input type="radio" name="gender" value="male" class="form__input-radio"> Male <br>
                    <input type="radio" name="gender" value="female" class="form__input-radio"> Female <br>
                    </div>
                </div><br>
                <div class="form__row">
                    <label for="dist"><sup class="req">*</sup>District : </label>
                    <select name="dis" id="dist" class="form__input-text form__input-select" required>
                        <option value="">Select District</option>
                        <option value="anugul">Anugul</option>
                        <option value="balangir">Balangir</option>
                        <option value="balasore">Balasore</option>
                        <option value="bargarh">Bargarh</option>
                        <option value="bhadrak">Bhadrak</option>
                        <option value="boudh">Boudh</option>
                        <option value="cuttack">Cuttack</option>
                        <option value="deogarh">Deogarh</option>
                        <option value="dhenkanal">Dhenkanal</option>
                        <option value="gajapati">Gajapati</option>
                        <option value="ganjam">Ganjam</option>
                        <option value="jagatsinghapur">Jagatsinghapur</option>
                        <option value="jajpur">Jajpur</option>
                        <option value="jharsuguda">Jharsuguda</option>
                        <option value="kalahandi">Kalahandi</option>
                        <option value="kandhamal">Kandhamal</option>
                        <option value="kendrapara">Kendrapara</option>
                        <option value="keonjhar">Keonjhar</option>
                        <option value="khordha">Khordha</option>
                        <option value="koraput">Koraput</option>
                        <option value="malkangiri">Malkangiri</option>
                        <option value="mayurbhanj">Mayurbhanj</option>
                        <option value="nabarangpur">Nabarangpur</option>
                        <option value="nayagarh">Nayagarh</option>
                        <option value="nuapada">Nuapada</option>
                        <option value="puri">Puri</option>
                        <option value="rayagada">Rayagada</option>
                        <option value="sambalpur">Sambalpur</option>
                        <option value="sonepur">Sonepur</option>
                        <option value="sundargarh">Sundargarh</option>
                    </select>
                </div><br>
                <div class="form__row">
                    <label for="state"><sup class="req">*</sup>State: </label>
                    <select name="state" id="state" class="form__input-text form__input-select" required>
                        <option value="" style="color: #fff;">Select State</option>
                        <option value="Andaman and Nicobar Islands">Andaman and Nicobar Islands</option>
                        <option value="Andhra Pradesh">Andhra Pradesh</option>
                        <option value="Arunachal Pradesh">Arunachal Pradesh</option>
                        <option value="Assam">Assam</option>
                        <option value="Bihar">Bihar</option>
                        <option value="Chandigarh">Chandigarh</option>
                        <option value="Chhattisgarh">Chhattisgarh</option>
                        <option value="Dadra and Nagar Haveli">Dadra and Nagar Haveli</option>
                        <option value="Daman and Diu">Daman and Diu</option>
                        <option value="Delhi">Delhi</option>
                        <option value="Goa">Goa</option>
                        <option value="Gujarat">Gujarat</option>
                        <option value="Haryana">Haryana</option>
                        <option value="Himachal Pradesh">Himachal Pradesh</option>
                        <option value="Jammu and Kashmir">Jammu and Kashmir</option>
                        <option value="Jharkhand">Jharkhand</option>
                        <option value="Karnataka">Karnataka</option>
                        <option value="Kerala">Kerala</option>
                        <option value="Lakshadweep">Lakshadweep</option>
                        <option value="Madhya Pradesh">Madhya Pradesh</option>
                        <option value="Maharashtra">Maharashtra</option>
                        <option value="Manipur">Manipur</option>
                        <option value="Meghalaya">Meghalaya</option>
                        <option value="Mizoram">Mizoram</option>
                        <option value="Nagaland">Nagaland</option>
                        <option value="Orissa">Odisha</option>
                        <option value="Pondicherry">Pondicherry</option>
                        <option value="Punjab">Punjab</option>
                        <option value="Rajasthan">Rajasthan</option>
                        <option value="Sikkim">Sikkim</option>
                        <option value="Tamil Nadu">Tamil Nadu</option>
                        <option value="Tripura">Tripura</option>
                        <option value="Uttaranchal">Uttaranchal</option>
                        <option value="Uttar Pradesh">Uttar Pradesh</option>
                        <option value="West Bengal">West Bengal</option>
                    </select>
                </div><br>
                <div class="form__row">
                    <label for="country"><sup class="req">*</sup>Country : </label>
                    <input type="text" name="coun" id="country" class="form__input-text" value="India">
                </div><br>
                <div class="form__row">
                    <label for="aadhaar"><sup class="req">*</sup>Aadhaar No. : </label>
                    <input type="text" name="adhr" pattern="\d{12}" maxlength="12" id="aadhaar" class="form__input-text" placeholder="Enter 12 digit Aadhaar No" required>
                </div><br>
                <div class="form__row">
                    <label for="pan"><sup class="req">*</sup>PAN No. : </label>
                    <input type="text" name="pan" id="pan" class="form__input-text" required>
                </div><br>
                <div class="form_checkbox-container">
                    <label for="specialisation">Specialisation : </label><br>
                    <div class="form__row-checkbox">
                        <input type="checkbox" name="work[]" value="a" id="a" class="form__input-checkbox"><label for="a"> Cooking</label><br>
                        <input type="checkbox" name="work[]" value="b" id="b" class="form__input-checkbox"><label for="b"> Dusting and Utensils cleaning</label><br>
                        <input type="checkbox" name="work[]" value="c" id="c" class="form__input-checkbox"><label for="c"> Attending Guests</label><br>
                        <input type="checkbox" name="work[]" value="d" id="d" class="form__input-checkbox"><label for="d"> Attending visitors</label><br><br>
                        <label for="e"> Others: </label>
                        <input type="text" id="e" name="work[]" class="form__input-text" placeholder="Please specify if any other">
                    </div>
                </div><br>
                <div class="form__row">
                    <label for="personal-details" style="align-self: flex-start;">Personal details : </label>
                    <textarea name="dt" id="personal-details" cols="35" rows="5" class="form__textarea"></textarea>
                </div><br>
                <div class="btn-container">
                    <input type="submit" value="Submit" class="btn btn-submit">
                </div>
            </form>
        </section>
    </main>

<?php
if(isset($_POST["submit"])){
if(empty($sn=$_POST['fname'])){
    echo "name is required";
}

$cl=$_POST['lname'];
$adr=$_POST['adr'];
$gender=$_POST['gender'];
$dis=$_POST['dis'];
$state=$_POST['state'];
$coun=$_POST['coun'];
$adhar=$_POST['adhr'];
$pan=$_POST['pan'];
$Specification=$_POST['work'];
$b=implode(",",$Specification);
$dt=$_POST['dt'];

$query = "INSERT INTO u VALUES ('$sn','$cl','$adr','$gender','$dis','$state','$coun','$adhar','$pan','$b','$dt')";
$data = mysqli_query($conn,$query);

if($data)
{
    echo "data inserted into database";
}}

?>

</body>
</html>
